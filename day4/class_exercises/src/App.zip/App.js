import './App.css';
import Counter from './components/counter';

function App() {
  return(
    <>
      <Counter />
    </>
  )
}

export default App;